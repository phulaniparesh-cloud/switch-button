# Switch

A Pen created on CodePen.

Original URL: [https://codepen.io/kLeosrisook/pen/VweNjrV](https://codepen.io/kLeosrisook/pen/VweNjrV).

My first animation using anime.js library! 